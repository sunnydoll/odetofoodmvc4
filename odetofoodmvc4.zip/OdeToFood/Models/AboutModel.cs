﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OdeToFood.Models
{
    public class AboutModel
    {
        public string Name { get; set; }
        public string Location { get; set; }
    }
}